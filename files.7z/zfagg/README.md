# BackupCore
A cross-platform commandline/config-based program to back up and archive files written in .NET Core 2.0.
